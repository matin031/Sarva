import type { Metadata } from "next";
import { Vazirmatn } from "next/font/google";
import "./globals.css";
import Header from "@/components/UI/Header";
import { GeometricPattern } from "@/components/persian-patterns";

import { ToastContainer } from "react-toastify";
import Footer from "@/components/UI/Footer";
import { Suspense } from "react";
import { NavigationProgress } from "@/components/UI/NavigationProgress";

const vazirmatn = Vazirmatn({
  subsets: ["arabic", "latin"],
  variable: "--font-vazirmatn",
  display: "swap",
});

export const metadata: Metadata = {
  title: "عروضینو | آموزش وزن شعر فارسی",
  verification: {
    google: "44Gf_E9roc0H5qi8iWxWmEMyZXUJQRRZ0DQ",
  },
  description:
    "پلتفرم آموزشی تعاملی برای یادگیری اوزان عروضی شعر فارسی - با الهام از زیبایی‌شناسی ایرانی",
  keywords: ["عروض", "شعر فارسی", "وزن شعر", "ادبیات فارسی", "آموزش شعر"],
  authors: [{ name: "عروضینو" }],
  icons: {
    icon: "/favicon.svg", // مهم: حتماً / در اول باشه
    shortcut: "/favicon.svg",
    apple: "/favicon.svg", // برای iOS
  },
  openGraph: {
    title: "عروضینو | آموزش وزن شعر فارسی",
    description: "پلتفرم آموزشی تعاملی برای یادگیری اوزان عروضی شعر فارسی",
    locale: "fa_IR",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="fa"
      className={`${vazirmatn.variable}  h-full antialiased dark`}
    >
      <body className="text-right  flex flex-col min-h-screen">
        <Suspense>
          <NavigationProgress />
        </Suspense>
        <Header />
        <main className="flex-1">{children}</main>
        <Footer />
        <GeometricPattern
          className="z-10 fixed text-gold h-screen"
          opacity={0.06}
        />
        <ToastContainer
          position="top-center"
          autoClose={5000}
          hideProgressBar={false}
          newestOnTop={false}
          closeOnClick={false}
          rtl={true}
          pauseOnFocusLoss
          draggable
          pauseOnHover
          theme="dark"
        />
      </body>
    </html>
  );
}
